/*
       Write a Java program that displays your name, CIT260 and your section, your home town, and your favorite dessert.
       Name the class in your program W1dot1. The output of your program should look like the example below:

        Jeremiah Jones
        CIT260-07
        Lehi, Utah
        Banana Cream Pie
*/

public class W1dot1 {

    public static void main(String[] args){
        System.out.println("Sunday Ogbonnaya Onwuchekwa");
        System.out.println("CIT260-06");
        System.out.println("Accra, Ghana");
        System.out.println("Strawberry Ice Cream");
    }
}
